package com.networkchat;

import java.net.Socket;

public class ClientHandlerFactory {
    /**
     * Creates a new ClientHandler for a given socket.
     * @param socket the socket connected to a client; must not be null.
     * @return a new ClientHandler instance.
     * @pre socket != null
     */
    public static ClientHandler createClientHandler(Socket socket) {
        return new ClientHandler(socket);
    }
}
