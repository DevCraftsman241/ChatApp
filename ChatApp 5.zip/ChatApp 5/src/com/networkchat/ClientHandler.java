package com.networkchat;

import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable, Observer {
    Socket socket;
    PrintWriter out;
    BufferedReader in;
    String clientId;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    /**
     * Returns true if the socket is still open.
     */
    public boolean isAlive() {
        return !socket.isClosed();
    }

    @Override
    public void run() {
        boolean registered = false;
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Prompt for a unique client ID.
            while (!registered) {
                out.println("Enter Client ID:");
                clientId = in.readLine();
                if (clientId == null) {
                    return; // Client disconnected.
                }
                if (!Server.getInstance().addClient(clientId, this)) {
                    out.println("Client ID already in use. Please enter a unique Client ID.");
                } else {
                    registered = true;
                }
            }

            // Print to the server console that this client has joined.
            System.out.println(clientId + " has joined.");

            // Inform the client of the coordinator.
            if (clientId.equals(Server.getInstance().getCoordinatorId())) {
                out.println("You are the coordinator.");
                System.out.println(clientId + " is the coordinator.");
            } else {
                out.println("Current coordinator: " + Server.getInstance().getCoordinatorId());
            }

            String command;
            while ((command = in.readLine()) != null) {
                if (command.equalsIgnoreCase("q")) {
                    break;
                } else if (command.equalsIgnoreCase("b")) {
                    String messageContent = in.readLine();
                    Server.getInstance().broadcastMessage(clientId, messageContent);
                } else if (command.equalsIgnoreCase("p")) {
                    String recipient = in.readLine();
                    String messageContent = in.readLine();
                    sendPrivateMessage(clientId, recipient, messageContent);
                } else if (command.equalsIgnoreCase("list")) {
                    sendClientList();
                }
            }
        } catch (IOException e) {
            System.out.println(clientId + " disconnected unexpectedly.");
        } finally {
            if (registered) {
                Server.getInstance().removeClient(clientId);
            }
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Sends a private message to a specific client.
     * Changed to public so test classes can call it.
     */
    public void sendPrivateMessage(String sender, String recipient, String content) {
        Message message = new Message(sender, recipient, Message.MessageType.PRIVATE, content);
        ClientHandler client = Server.getInstance().getClients().get(recipient);
        if (client != null) {
            client.out.println(message.toString());
        } else {
            out.println("User " + recipient + " not found.");
        }
    }

    /**
     * Sends the list of active clients with their connection details.
     */
    public void sendClientList() {
        out.println("Active Members:");
        for (String id : Server.getInstance().getClients().keySet()) {
            ClientHandler handler = Server.getInstance().getClients().get(id);
            String info = handler.getClientInfo();
            if (id.equals(Server.getInstance().getCoordinatorId())) {
                out.println(id + " (" + info + ") [Coordinator]");
            } else {
                out.println(id + " (" + info + ")");
            }
        }
    }

    /**
     * Returns the client's connection info.
     */
    public String getClientInfo() {
        return socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
    }

    /**
     * Implements the Observer update method.
     */
    @Override
    public void update(String message) {
        out.println(message);
    }
}
