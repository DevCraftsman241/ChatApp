package com.networkchat;

import java.io.*;
        import java.net.*;

public class Client {
    public static void main(String[] args) {
        try (BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter Server IP Address: ");
            String serverAddress = consoleInput.readLine();
            System.out.print("Enter Server Port: ");
            int serverPort = Integer.parseInt(consoleInput.readLine());

            try (Socket socket = new Socket(serverAddress, serverPort);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                // Handle initial handshake for Client ID.
                String serverMessage = in.readLine();
                System.out.println(serverMessage);
                String clientId = consoleInput.readLine();
                out.println(clientId);

                while (true) {
                    serverMessage = in.readLine();
                    if (serverMessage == null) break;
                    if (serverMessage.startsWith("Client ID already in use")) {
                        System.out.println(serverMessage);
                        serverMessage = in.readLine();
                        System.out.println(serverMessage);
                        clientId = consoleInput.readLine();
                        out.println(clientId);
                    } else if (serverMessage.startsWith("You are the coordinator.") ||
                            serverMessage.startsWith("Current coordinator:")) {
                        System.out.println(serverMessage);
                        break;
                    } else {
                        System.out.println(serverMessage);
                    }
                }

                // Start a thread to continuously listen for messages.
                new Thread(() -> {
                    try {
                        String response;
                        while ((response = in.readLine()) != null) {
                            System.out.println(response);
                        }
                    } catch (IOException ignored) { }
                }).start();

                // Main loop to send commands.
                String command;
                while (true) {
                    System.out.println("Enter 'b' for broadcast, 'p' for private, 'list' for active members, 'q' to quit:");
                    command = consoleInput.readLine();
                    out.println(command);
                    if (command.equalsIgnoreCase("q")) break;

                    if (command.equalsIgnoreCase("b")) {
                        System.out.print("Message: ");
                        out.println(consoleInput.readLine());
                    } else if (command.equalsIgnoreCase("p")) {
                        System.out.print("Recipient: ");
                        out.println(consoleInput.readLine());
                        System.out.print("Message: ");
                        out.println(consoleInput.readLine());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
