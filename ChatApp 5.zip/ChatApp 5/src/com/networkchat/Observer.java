package com.networkchat;

public interface Observer {
    /**
     * Updates the observer with a new message.
     * @param message The message to deliver.
     */
    void update(String message);
}
