package com.networkchat;

import java.util.Date;

public class Message {
    public enum MessageType {
        BROADCAST,
        PRIVATE
    }

    private final String sender;
    private final String recipient; // Null for broadcast messages.
    private final MessageType type;
    private final String content;
    private final Date timestamp;

    /**
     * Constructor for broadcast messages.
     * @param sender The sender's ID.
     * @param content The message content.
     */
    public Message(String sender, String content) {
        this(sender, null, MessageType.BROADCAST, content);
    }

    /**
     * Constructor for all message types.
     * @param sender The sender's ID.
     * @param recipient The recipient's ID (null for broadcast).
     * @param type The type of message.
     * @param content The message content.
     */
    public Message(String sender, String recipient, MessageType type, String content) {
        this.sender = sender;
        this.recipient = recipient;
        this.type = type;
        this.content = content;
        this.timestamp = new Date();
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public MessageType getType() {
        return type;
    }

    public String getContent() {
        return content;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        String timeStr = "[" + timestamp + "]";
        if (type == MessageType.PRIVATE) {
            return timeStr + " Private from " + sender + " to " + recipient + ": " + content;
        } else {
            return timeStr + " " + sender + ": " + content;
        }
    }
}
