package com.networkchat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    public static final int DEFAULT_PORT = 5050;
    private static Server instance;

    // Shared state: active clients, coordinator, and message log.
    private final Map<String, ClientHandler> clients = new ConcurrentHashMap<>();
    private volatile String coordinatorId = null;
    private final List<String> messageLog = new CopyOnWriteArrayList<>();

    // Private constructor for Singleton.
    private Server() { }

    /**
     * Returns the single instance of Server.
     * @return the singleton instance.
     */
    public static synchronized Server getInstance() {
        if (instance == null) {
            instance = new Server();
        }
        return instance;
    }

    /**
     * Starts the server on the given port.
     * @param port The port number to listen on.
     * @pre port > 1024
     */
    public void startServer(int port) {
        System.out.println("Server started on port " + port);
        ExecutorService pool = Executors.newCachedThreadPool();

        // Periodically check for inactive clients.
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                checkActiveClients();
            }
        }, 0, 20000);

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket socket = serverSocket.accept();
                // Create a new ClientHandler using the factory.
                ClientHandler clientHandler = ClientHandlerFactory.createClientHandler(socket);
                pool.execute(clientHandler);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            pool.shutdown();
        }
    }

    /**
     * Checks for inactive clients and removes them.
     */
    private synchronized void checkActiveClients() {
        List<String> inactiveClients = new ArrayList<>();
        for (Map.Entry<String, ClientHandler> entry : clients.entrySet()) {
            if (!entry.getValue().isAlive()) {
                inactiveClients.add(entry.getKey());
            }
        }
        for (String clientId : inactiveClients) {
            removeClient(clientId);
        }
    }

    /**
     * Logs a message with a timestamp.
     * @param message The message to log.
     * @pre message != null
     */
    public synchronized void logMessage(String message) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        messageLog.add("[" + timestamp + "] " + message);
    }

    /**
     * Adds a client if the clientId is unique.
     * @param clientId The client's unique identifier.
     * @param handler  The client's handler.
     * @return true if added, false if the id is already in use.
     * @pre clientId != null && handler != null
     */
    public synchronized boolean addClient(String clientId, ClientHandler handler) {
        if (clients.containsKey(clientId)) {
            return false;
        }
        clients.put(clientId, handler);
        if (coordinatorId == null) {
            coordinatorId = clientId;
        }
        return true;
    }

    /**
     * Removes a client from the active list.
     * @param clientId The ID of the client to remove.
     * @pre clientId != null
     */
    public synchronized void removeClient(String clientId) {
        if (clients.containsKey(clientId)) {
            clients.remove(clientId);
            System.out.println(clientId + " has left the chat.");
            if (clientId.equals(coordinatorId)) {
                assignNewCoordinator();
            }
        }
    }

    /**
     * Reassigns the coordinator if necessary and notifies all clients.
     */
    private synchronized void assignNewCoordinator() {
        if (!clients.isEmpty()) {
            // Choose the first client in the map as the new coordinator.
            Map.Entry<String, ClientHandler> newCoordinator = clients.entrySet().iterator().next();
            coordinatorId = newCoordinator.getKey();
            System.out.println("New coordinator assigned: " + coordinatorId);

            // Broadcast to all clients about the new coordinator.
            notifyObservers("New coordinator assigned: " + coordinatorId);

            // Directly notify the new coordinator.
            newCoordinator.getValue().out.println("You are now the coordinator.");
        } else {
            coordinatorId = null;
        }
    }

    /**
     * Notifies all connected clients (observers) with a message.
     * @param message The message to broadcast.
     */
    public void notifyObservers(String message) {
        for (ClientHandler client : clients.values()) {
            client.update(message);
        }
    }

    /**
     * Broadcasts a message to all clients.
     * @param sender The sender's ID.
     * @param content The message content.
     * @pre content != null
     */
    public synchronized void broadcastMessage(String sender, String content) {
        Message message = new Message(sender, content);
        logMessage(message.toString());
        notifyObservers(message.toString());
    }

    /**
     * Returns a copy of the active clients.
     * @return a new ConcurrentHashMap of clients.
     */
    public synchronized Map<String, ClientHandler> getClients() {
        return new ConcurrentHashMap<>(clients);
    }

    /**
     * Returns the current coordinator's ID.
     * @return the coordinatorId.
     */
    public synchronized String getCoordinatorId() {
        return coordinatorId;
    }

    public static void main(String[] args) {
        int port = DEFAULT_PORT;
        Server server = Server.getInstance();
        server.startServer(port);
    }
}
