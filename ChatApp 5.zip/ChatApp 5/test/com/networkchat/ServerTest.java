package com.networkchat;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ServerTest {

    private Server server;

    @BeforeEach
    public void setup() {
        // Get the singleton server instance and clear previous state.
        server = Server.getInstance();
        // Remove existing clients if needed.
        for (String clientId : server.getClients().keySet()) {
            server.removeClient(clientId);
        }
    }

    @Test
    public void testSingletonInstance() {
        Server anotherServer = Server.getInstance();
        assertSame(server, anotherServer, "Server should be a singleton.");
    }

    @Test
    public void testAddClient() {
        // Use a dummy ClientHandler (socket can be null for testing)
        ClientHandler dummyHandler = new ClientHandler(null);
        boolean added = server.addClient("TestClient", dummyHandler);
        assertTrue(added, "Client should be added successfully.");

        // Adding the same client again should fail.
        boolean addedAgain = server.addClient("TestClient", dummyHandler);
        assertFalse(addedAgain, "Duplicate client ID should not be allowed.");
    }
}
